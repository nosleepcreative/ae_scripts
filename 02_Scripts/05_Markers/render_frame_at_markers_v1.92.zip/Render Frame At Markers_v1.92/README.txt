 INSTALLATION

(1) copy the file "Render Frame At Markers.jsx" into the folder:

"Support Files/Scripts" (on Windows) or
"Scripts" (on Mac) 

of your After Effects installation. 

Note that is should be installed in the "Scripts" folder and not the "ScriptUI Panels" folder

(2) Start "Render Frame At Markers" (via the File->Scripts menu in After Effects)

ABOUT

Will send to the render queue any frames that are marked by layer markers that are within the comp work area. This would be equivalent to going to a point in time in your comp and selecting "Save Frame As->File"


HOW TO ADD AS FT-TOOLBAR BUTTON

Make sure the script is installed in the Scripts folder (not the ScriptUI Panels folder)
Add a "SCRIPT LAUNCHER" button and point it to the Reveal in Finder.jsxbin file in the Scripts folder.
